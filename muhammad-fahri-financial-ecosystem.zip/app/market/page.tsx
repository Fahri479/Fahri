export default function Market() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Market Dashboard</h1>
      <div className="bg-white/5 p-6 rounded-2xl">
        Dummy Market Dashboard (BTC, ETH, IHSG, SP500, dll)
      </div>
    </div>
  );
}
