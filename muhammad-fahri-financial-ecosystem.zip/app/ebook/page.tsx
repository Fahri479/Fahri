export default function Ebook() {
  return (
    <div className="p-8 text-center">
      <h1 className="text-4xl font-bold mb-6">Ebook Premium Trading</h1>
      <p className="mb-6">Strategi lengkap risk management & mindset profesional.</p>
      <a href="http://lynk.id/fahri_gnz" target="_blank"
        className="bg-gold text-black px-6 py-3 rounded-xl">
        Beli Sekarang
      </a>
    </div>
  );
}
